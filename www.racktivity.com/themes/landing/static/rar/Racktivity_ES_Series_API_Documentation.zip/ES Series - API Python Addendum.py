def bin2version(data):
    major = bin2int(data[0])
    minor = bin2int(data[1])
    return float("%d.%d" % (major, minor))

def bin2bool(data):
    return bool(bin2int(data))

def bin2string(data):
    idx = data.find('\x00')
    if idx != -1:
        data = data[:idx]
    return data

def bin2ipaddress(data):
    chunks = list()
    for chunk in data:
        chunks.append(bin2int(chunk))
    return ".".join((str(x) for x in chunks))

def bin2macaddress(data):
    mac = binascii.b2a_hex(data)
    chunks = list()
    for x in xrange(len(mac)):
        if x %2 == 0:
            chunks.append(mac[x:x+2])
    return ":".join(chunks)

def bin2int(data):
    nr = 0
    for idx, byte in enumerate(data):
        nr += ord(byte)*(256**idx)
    return nr

#bin2signed int
def bin2sint(data):
    nr = 0
    #convert binary bytes into digits
    arr = list()
    for byte in data:
        arr.append(ord(byte))
    byteslen = len(data)
    #Now do the processing
    negative = False
    if arr[byteslen - 1] >= 128:
         negative = True
    for idx, byte in enumerate(arr):
        if negative:
            byte = byte ^ 0xff
        nr += byte * (256**  idx)
    if negative:
        nr = (nr + 1) * -1
    return nr
